
public class personne {


@Override
	public String toString() {
		return "Je suis une personne du [NOM = " + nom + ", PRENOM = " + prenom + ", NO_TELPHONE = "
				+ no_telphone + "]";
	}



String nom;
String prenom;
String no_telphone;

//Constructeur
public personne(String nom, String prenom, String no_telphone) {
	super();
	this.nom = nom;
	this.prenom = prenom;
	this.no_telphone = no_telphone;
}	
	
public personne(String nom2, String prenom2) {
	// TODO Auto-generated constructor stub
}

	//SETTERS and GETTERS	
	/**
	 * @return the nOM
	 */
	public String getNOM() {
		return nom;
	}
	/**
	 * @param nOM the nOM to set
	 */
	public void setNOM(String nOM) {
		nom = nOM;
	}
	/**
	 * @return the pRENOM
	 */
	public String getPRENOM() {
		return prenom;
	}
	/**
	 * @param pRENOM the pRENOM to set
	 */
	public void setPRENOM(String pRENOM) {
		prenom = pRENOM;
	}
	/**
	 * @return the nO_TELPHONE
	 */
	public String getNO_TELPHONE() {
		return no_telphone;
	}
	/**
	 * @param nO_TELPHONE the nO_TELPHONE to set
	 */
	public void setNO_TELPHONE(String nO_TELPHONE) {
		no_telphone = nO_TELPHONE;
	}
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
 personne x = new personne ("LORRE","PETER","125487");
 System.out.println(x);
	}

}
