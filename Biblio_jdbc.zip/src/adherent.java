import java.time.LocalDate;
import java.util.Date;

public class adherent extends personne{

static int no_carte;
LocalDate date_cotisation;
int retard;
int nbemprunt;
emprunts emprunt;

public adherent(String nom, String prenom, String no_telphone, int no_carte,
	int retard, int nbemprunt) {
	super(nom, prenom, no_telphone);
	this.no_carte = no_carte;
	this.retard = retard;
	this.nbemprunt = nbemprunt;
}

public adherent(String nom, String prenom, String no_telphone, int retard,
	int nbemprunt) {
	super(nom, prenom, no_telphone);
	this.retard = retard;
	this.nbemprunt = nbemprunt;
}

@Override
public String toString() {
	return "Je suis un adherent du nom : " + nom + ", prenom = " + prenom
			+ ", no_telphone = " + no_telphone + " no de carte = "+ no_carte
			+ " , nb emprunts = "+ nbemprunt + " , retard = "+retard + " "; }
			

public emprunts getEmprunt() {
	return emprunt;
}


public void setEmprunt(emprunts emprunt) throws biblioException {
if (this.nbemprunt >= 3) {System.err.println("IMPOSSIBLE!!! NOMBRE MAX EMPRUNTS ATTEINT!!!");throw new biblioException();}
	if (this.retard == 1) {System.err.println("RETARD!!!  COMPTE SUSPENDU!!!");throw new biblioException();} 
	else {this.emprunt = emprunt;}
}


public static int getNo_carte() {
	return no_carte;
}

public void setNo_carte(int no_carte) {
	this.no_carte = no_carte;
}

public LocalDate getDate_cotisation() {
	return date_cotisation;
}


public void setDate_cotisation(LocalDate date_cotisation) {
	this.date_cotisation = date_cotisation;
}


public int getRetard() {
	return retard;
}


public void setRetard(int retard) {
	this.retard = retard;
}

public int getNbemprunt() {
	return nbemprunt;
}

public void setNbemprunt(int nbemprunt) {
	this.nbemprunt = nbemprunt;
}










public static void main(String[] args) {
	 System.out.println(Adh_Dao.findbykey(202));
	
	}

}
