
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class ConnectionFactory {
	public static Connection ConnectionFactoryCommit()  {
	Properties props = new Properties();
	try (FileInputStream fil = new FileInputStream  ("jdbc.properties")){
	 props.load (fil);	
	}catch (FileNotFoundException ee1) {
		ee1.printStackTrace();
	} catch (IOException ee) {
		ee.printStackTrace();
	}
		
	//System.out.println(props.getProperty("jdbc.driver.class"));
	try {
	Class.forName(props.getProperty("jdbc.driver.class"));}
	catch (ClassNotFoundException e) {
		System.err.println("classe introuvable");
	}
	String url = props.getProperty("jdbc.url");
	String login = props.getProperty("jdbc.login");
	String pwd = props.getProperty("jdbc.password");
	
	Connection con = null;
	try {con = DriverManager.getConnection(url,login,pwd);}
		 catch (SQLException e) {
				e.printStackTrace();
			}
			return con;
}

	public static Connection ConnectionFactorySsCommit()  {
		Properties props = new Properties();
		try (FileInputStream fil = new FileInputStream  ("jdbc.properties")){
		 props.load (fil);	
		}catch (FileNotFoundException ee1) {
			ee1.printStackTrace();
		} catch (IOException ee) {
			ee.printStackTrace();
		}
			
		//System.out.println(props.getProperty("jdbc.driver.class"));
		try {
		Class.forName(props.getProperty("jdbc.driver.class"));}
		catch (ClassNotFoundException e) {
			System.err.println("classe introuvable");
		}
		String url = props.getProperty("jdbc.url");
		String login = props.getProperty("jdbc.login");
		String pwd = props.getProperty("jdbc.password");
		
		Connection con = null;
		try {con = DriverManager.getConnection(url,login,pwd);
		     con.setAutoCommit(false); 	}
			 catch (SQLException e) {
					e.printStackTrace();
				}
				return con;
	}


}
