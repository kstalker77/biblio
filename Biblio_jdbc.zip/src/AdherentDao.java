import java.sql.*;
import java.time.LocalDate;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
public class AdherentDao {
	static LocalDate here = LocalDate.now();
	static int nbemprunt=9;
public static void connection () {
	JPanel panel = new JPanel();
	JLabel label = new JLabel("Enter a password:");
	JPasswordField pass = new JPasswordField(10);
	panel.add(label);
	panel.add(pass);
	String[] options = new String[]{"OK", "Cancel"};
	int option = JOptionPane.showOptionDialog(null, panel, "Connection...",
	                         JOptionPane.NO_OPTION, JOptionPane.PLAIN_MESSAGE,
	                         null, options, options[1]);
	if(option == 0) // pressing OK button
	{
	    char[] password = pass.getPassword();
	    String pass1= new String(password);
	    if (pass1.equalsIgnoreCase("xavier")) {System.out.println("Logging...");}
	    else {connection();}
	}
	}
	

	

	
public static adherent findAdherent () throws SQLException {
	
	 Connection conn = ConnectionFactory.ConnectionFactoryCommit();
		if (conn==null){
		System.out.println("Error connecting to DB");
		System.exit(0);	
		}
		System.out.println("Connecting...");
		JFrame frame = new JFrame("InputDialog Example #1");
		String x = JOptionPane.showInputDialog(frame, "Entrez No Adherent???");
		String x2 =("select * from adherent where no_carte ="+Integer.valueOf(x));
		String stt=x2;
		Statement stat = conn.createStatement();
		ResultSet rset=  stat.executeQuery(stt);
				while( rset.next()) {
				String nom = rset.getNString(1);
				String prenom = rset.getNString(2);
				String Tel = rset.getNString(3);
				int no_carte = rset.getInt(4);
				Date date = rset.getDate(5);
				int retard = rset.getInt(6);
				int nbemprunts = rset.getInt(7);
						
				if (no_carte < 1000) {		
				System.out.println("Employé du nom : "+nom+" Prenom : "+prenom+" No Tel : "+ Tel +" No Carte : "+no_carte+" Date : "+date+" Est en retard : "+retard+" Nombre d'emprunts :"+nbemprunts );
				employe emp = new employe (nom,prenom,Tel,no_carte);
				System.out.println(emp); return null;
				}	
				else {
					System.out.println("Adherent du nom : "+nom+" Prenom : "+prenom+" No Tel : "+ Tel +" No Carte : "+ no_carte +" Date : "+date+" Est en retard : "+retard+" Nombre d'emprunts : "+nbemprunts );}
				adherent adh = new adherent(nom,prenom,Tel,no_carte,retard,nbemprunts);
				System.out.println(adh);
			
				return adh;
			}	 
		 
	 return null;

	 
 }

 public static employe findEmploye () throws SQLException {
		
	 Connection conn = ConnectionFactory.ConnectionFactoryCommit();
		if (conn==null){
		System.out.println("Error connecting to DB");
		System.exit(0);	
		}
		System.out.println("Connecting...");
		JFrame frame = new JFrame("InputDialog Example #1");
		String x = JOptionPane.showInputDialog(frame, "Entrez No Employé???");
		String x2 =("select * from adherent where no_carte ="+Integer.valueOf(x));
		String stt=x2;
		Statement stat = conn.createStatement();
		ResultSet rset=  stat.executeQuery(stt);
				while( rset.next()) {
				String nom = rset.getNString(1);
				String prenom = rset.getNString(2);
				String Tel = rset.getNString(3);
				int no_carte = rset.getInt(4);
				Date date = rset.getDate(5);
				int retard = rset.getInt(6);
				int nbemprunts = rset.getInt(7);
						
				if (no_carte < 1000) {		
				System.out.println("Employé du nom : "+nom+" Prenom : "+prenom+" No Tel : "+ Tel +" No Carte : "+no_carte+" Date : "+date+" Est en retard : "+retard+" Nombre d'emprunts :"+nbemprunts );
				employe emp = new employe (nom,prenom,Tel,no_carte);
				System.out.println(emp); return emp;
				}	
				else {
					System.out.println("Adherent du nom : "+nom+" Prenom : "+prenom+" No Tel : "+ Tel +" No Carte : "+ no_carte +" Date : "+date+" Est en retard : "+retard+" Nombre d'emprunts : "+nbemprunts );}
				adherent adh = new adherent(nom,prenom,Tel,no_carte,retard,nbemprunts);
				System.out.println(adh);
			
				return null;
			}	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 return null;

	 
 }

 public static void setEmprunt () throws SQLException, biblioException{
	LocalDate date2 = here.plusDays(15);
	livre li = livreDao.findLivre();
	adherent adh = findAdherent();
	emprunts emp  = new emprunts (emprunts.no_emprunt,li.ID_LIVRE,LocalDate.now(),adh.retard,0,adh.no_carte,here.plusDays(15));
	adh.nbemprunt+=1;
	emprunts.no_emprunt+=1;
	try {
	adh.setEmprunt(emp); 
	
	
	 Connection conn = ConnectionFactory.ConnectionFactoryCommit();
		if (conn==null){
		System.out.println("Error connecting to DB");
		System.exit(0);	
		}
		System.out.println("Connecting...");
		Statement stat = conn.createStatement();
		
	System.out.println("Inserting records into the table...");
     int no_emp = nbemprunt;
     int id_liv=li.ID_LIVRE;
     String date=here.toString();
     int enretard =adh.retard;
     int archive = 0;
     int no_carte = adh.no_carte;
     String date3=date2.toString();
     System.out.println("("+no_emp+","+id_liv+",'"+date+"',"+enretard+","+archive+","+no_carte+",'"+date3+"')");
     String sql = "INSERT INTO emprunts"+
    		 	  "(NO_EMPRUNT,ID_LIVRE,DATE_EMPRUNT,ENRETARD,ARCHIVE,ADHERENT_NO_CARTE,DATE_RETOUR)"+
                  "VALUES ("+no_emp+","+id_liv+",'"+date+"',"+enretard+","+archive+","+no_carte+",'"+date3+"')";
                  
     stat.executeUpdate(sql);
    System.out.println("Table Updated...");
    
    conn.close();}
    catch (biblioException e) {System.out.println(e);}
	}
	
 
 public static void setEmprunts () throws SQLException, biblioException{
	 
		livre li = livreDao.findLivre();
		employe adh = findEmploye();
		emprunts emp  = new emprunts (emprunts.no_emprunt,li.ID_LIVRE,LocalDate.now(),adh.retard,0,adh.no_carte,here.plusDays(15));
		adh.nbemprunt+=1;
		emprunts.no_emprunt+=1;
		adh.setEmprunt(emp);
		
		 
	 } 

	public static void main(String[] args) throws SQLException, biblioException {
	connection ();	
	//findAdherent();
	//findEmploye();
	//livreDao.findLivre();
	//livreDao.findLivre();
	setEmprunt();
	//setEmprunts();
	//setEmprunt();
	//setEmprunts();
	}

}
