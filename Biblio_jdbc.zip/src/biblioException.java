
public class biblioException extends Exception{

	public biblioException () {
			super("Parametre incorrect");
		}					
		
	
		
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub

		}}