import java.time.LocalDate;
import java.util.Date;

public class emprunts {



@Override
	public String toString() {
		return "emprunts [no_emprunt=" + no_emprunt + ", id_livre=" + id_livre
				+ ", date_emprunt=" + date_emprunt + ", enretard=" + enretard
				+ ", archive=" + archive + ", adherent_no_carte="
				+ adherent_no_carte + ", date_retour=" + date_retour + "]";
	}





static LocalDate here = LocalDate.now();
static int no_emprunt;
int id_livre= livre.getID_LIVRE();
LocalDate date_emprunt = LocalDate.now();
int enretard;
int archive;
int adherent_no_carte= adherent.getNo_carte();
LocalDate date_retour = here.plusDays(15);

	/*
	 * public emprunts (livre,adherent) {
	 * 
	 * 
	 * this.no_emprunt = this.no_emprunt; this.id_livre = livre.getID_LIVRE();
	 * this.date_emprunt = date_emprunt; this.enretard = enretard; this.archive
	 * = archive; this.adherent_no_carte = adherent.getNo_carte();
	 * this.date_retour = date_retour;
	 * 
	 * 
	 * }
	 */

/**
 * @param no_emprunt
 * @param id_livre
 * @param date_emprunt
 * @param enretard
 * @param archive
 * @param adherent_no_carte
 * @param date_retour
 */
public emprunts(int no_emprunt, int id_livre, LocalDate date_emprunt,
		int enretard, int archive, int adherent_no_carte,
		LocalDate date_retour) {
	super();
	this.no_emprunt = no_emprunt;
	this.id_livre = id_livre;
	this.date_emprunt = date_emprunt;
	this.enretard = enretard;
	this.archive = archive;
	this.adherent_no_carte = adherent_no_carte;
	this.date_retour = date_retour;
}

/**
 * @return the no_emprunt
 */
public int getNo_emprunt() {
	return no_emprunt;
}

/**
 * @param no_emprunt the no_emprunt to set
 */
public void setNo_emprunt(int no_emprunt) {
	this.no_emprunt = no_emprunt;
}

/**
 * @return the id_livre
 */
public int getId_livre() {
	return id_livre;
}

/**
 * @param id_livre the id_livre to set
 */
public void setId_livre(int id_livre) {
	this.id_livre = id_livre;
}

/**
 * @return the date_emprunt
 */
public LocalDate getDate_emprunt() {
	return date_emprunt;
}

/**
 * @param date_emprunt the date_emprunt to set
 */
public void setDate_emprunt(LocalDate date_emprunt) {
	this.date_emprunt = date_emprunt;
}

/**
 * @return the enretard
 */
public int getEnretard() {
	return enretard;
}

/**
 * @param enretard the enretard to set
 */
public void setEnretard(int enretard) {
	this.enretard = enretard;
}

/**
 * @return the archive
 */
public int getArchive() {
	return archive;
}

/**
 * @param archive the archive to set
 */
public void setArchive(int archive) {
	this.archive = archive;
}

/**
 * @return the adherent_no_carte
 */
public int getAdherent_no_carte() {
	return adherent_no_carte;
}

/**
 * @param adherent_no_carte the adherent_no_carte to set
 */
public void setAdherent_no_carte(int adherent_no_carte) {
	this.adherent_no_carte = adherent_no_carte;
}

/**
 * @return the date_retour
 */
public LocalDate getDate_retour() {
	return date_retour;
}

/**
 * @param date_retour the date_retour to set
 */
public void setDate_retour(LocalDate date_retour) {
	this.date_retour = date_retour;
}





	public static void main(String[] args) throws biblioException {
		// TODO Auto-generated method stub
livre li = new livre(1003,"DREAMS","HIZO","SF",256547,"DISPO","NONE",0); 
//employe em = new employe("LORRE","PETER","22558877",202,202, "ME");
adherent e = new adherent("VALES","Jean","25987435",1003,0,0);
emprunts emp = new emprunts (1,li.ID_LIVRE,LocalDate.now(),0,0,e.no_carte,here.plusDays(15) );
try {
e.setEmprunt(emp);}
catch (biblioException e1){System.out.println(e1);}
System.out.println(emp);
	}

//e.setEmprunt(emp)	;
//System.out.println(emp);
}
