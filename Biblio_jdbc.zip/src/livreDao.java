

	import java.sql.*;
	import java.time.LocalDate;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
	public class livreDao {
public static livre findLivre () throws SQLException {
	
	
	
	Connection conn = ConnectionFactory.ConnectionFactorySsCommit();
	if (conn==null){
	System.out.println("Error connecting to DB");
	System.exit(0);	
	}
	System.out.println("Connecting...");
	
	
	JFrame frame = new JFrame("InputDialog Example #1");
	String x = JOptionPane.showInputDialog(frame, "Entrez Id livre???");
	String x2 =("select * from livre where id_livre="+Integer.valueOf(x));
	String stt=x2;
	Statement stat = conn.createStatement();
	ResultSet rset=  stat.executeQuery(stt);
	
		while( rset.next()) {
			int Idl =rset.getInt(1);
			String titre = rset.getString(2);
			String auteur = rset.getString(3);
			String theme = rset.getString(4);
			int isbn = rset.getInt(5);
			String etat = rset.getString(6);
			String comm = rset.getString(7);
			int statut = rset.getInt(8);
		
			System.out.println("ID_Livre : "+ Idl+" Titre : "+titre+" Auteur :"+auteur+" Theme : "+theme+" No ISBN : "+isbn+" Etat : "+etat+" Commentaires :"+ comm + "Statut = "+statut );
			livre liv = new livre (Idl,titre,auteur,theme,isbn,etat,comm,statut);
			System.out.println(liv);
			return liv;
		}
		return null;
		


	
}

	
	
	

	
		

		public static void main(String[] args) throws SQLException {
		
	findLivre();
				}
						
		}

	
