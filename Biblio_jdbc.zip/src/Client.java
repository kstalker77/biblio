
public class Client {



int noclient;
String nomclient;
String notelephone;

public Client(int noclient, String nomclient, String notelephone) {
	this.noclient = noclient;
	this.nomclient = nomclient;
	this.notelephone = notelephone;
}
/**
 * @return the noclient
 */
public int getNoclient() {
	return noclient;
}
/**
 * @param noclient the noclient to set
 */
public void setNoclient(int noclient) {
	this.noclient = noclient;
}
/**
 * @return the nomclient
 */
public String getNomclient() {
	return nomclient;
}
/**
 * @param nomclient the nomclient to set
 */
public void setNomclient(String nomclient) {
	this.nomclient = nomclient;
}
/**
 * @return the notelephone
 */
public String getNotelephone() {
	return notelephone;
}
/**
 * @param notelephone the notelephone to set
 */
public void setNotelephone(String notelephone) {
	this.notelephone = notelephone;
}
@Override
public String toString() {
	return "Client [ noclient = " + noclient + ", nomclient = " + nomclient
			+ ", notelephone = " + notelephone + "]";
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Client e = new Client (110,"Piotr Ivanovich","254986357");	
	System.out.println(e);
	}

}
