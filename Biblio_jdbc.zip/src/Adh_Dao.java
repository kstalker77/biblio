	
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

public class Adh_Dao {

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	//LocalDate date = LocalDate.parse("29-Mar-2019", formatter);
	public class UtilisateursDao {

		Connection con = null;

		public UtilisateursDao(Connection con) {
			this.con = con;
		}

		public adherent findByKey(int idUser) {
			Date maintenant = new Date(); // date actuelle
			System.out.println("Date actuelle :" + maintenant);
			
			//On spécialise la date courante
			//On n'utilise que le jour/mois/annee pour stockage dans BDR
			java.sql.Date dateSql = new java.sql.Date(maintenant.getTime());
			
			
			
			
			
			
			
			PreparedStatement pstm;
			employe user1 = null;
			adherent user = null;
			String nom = "";
			String prenom = "";
			String tel = "";
			int no_carte = (Integer) null;
			String date_cotisation = null;
			int retard;
			int nbemprunt;
			try {
				pstm = con
						.prepareStatement("select * from adherent");
				pstm.setInt(1, idUser);
				ResultSet result = pstm.executeQuery();
				while (result.next()) {
					nom = result.getString(1);
					prenom = result.getString(2);
					tel = result.getString(3);
					no_carte = result.getInt(4);
					date_cotisation=result.getString(5);
					retard=result.getInt(6);
					nbemprunt= result.getInt(7);
					
					
					if  (no_carte < 1000 ) {
					user1 = new employe (nom,prenom,tel,no_carte);
					System.out.println(user1);
					}
					if (no_carte > 1000) {
						
						user = new adherent (nom, prenom, tel,no_carte,retard,nbemprunt);
						System.out.println(user);
					}

				}

				pstm.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			return user;
			
		}

		
	}}

/*
 * public ArrayList<Utilisateur> findAll() { ArrayList<Utilisateur>
 * listUtilisateur = new ArrayList<Utilisateur>(); Utilisateur user = null;
 * String id = ""; String pwd = ""; String nom = ""; String prenom = ""; String
 * cat = ""; String tel = ""; String code = ""; String cat_employe = ""; try {
 * Statement stm = con.createStatement(); ResultSet result = stm
 * .executeQuery("select utilisateur.idutilisateur, utilisateur.pwd, utilisateur.nom, utilisateur.prenom, categorie_utilisateur, telephone, codematricule, categorieemploye "
 * + "from utilisateur, adherent, employe " +
 * "where utilisateur.idutilisateur=adherent.idutilisateur (+) " +
 * "and utilisateur.idutilisateur=employe.idutilisateur (+)"); while
 * (result.next()) { id = result.getString(1); pwd = result.getString(2); nom =
 * result.getString(3); prenom = result.getString(4); cat = result.getString(5);
 * if (cat.equals("ADHERENT")) { tel = result.getString(6); user = new
 * Adhérent(nom, prenom, id, pwd, tel); } if (cat.equals("EMPLOYE")) { code =
 * result.getString(7); cat_employe = result.getString(8); EnumCategorieEmploye
 * cat2 = EnumCategorieEmploye.valueOf(cat_employe.toLowerCase()); user = new
 * Employe(nom, prenom, id, pwd, code, cat2); }
 * 
 * listUtilisateur.add(user); } stm.close(); } catch (SQLException e) {
 * e.printStackTrace(); } return listUtilisateur; }
 * 
 * }
 */