
public class livre {


	


/**
	 * @return the iD_LIVRE
	 */
	public static int getID_LIVRE() {
		return ID_LIVRE;
	}

	/**
	 * @param iD_LIVRE the iD_LIVRE to set
	 */
	public void setID_LIVRE(int iD_LIVRE) {
		ID_LIVRE = iD_LIVRE;
	}

	/**
	 * @return the tITRE
	 */
	public String getTITRE() {
		return TITRE;
	}

	/**
	 * @param tITRE the tITRE to set
	 */
	public void setTITRE(String tITRE) {
		TITRE = tITRE;
	}

	/**
	 * @return the aUTEUR
	 */
	public String getAUTEUR() {
		return AUTEUR;
	}

	/**
	 * @param aUTEUR the aUTEUR to set
	 */
	public void setAUTEUR(String aUTEUR) {
		AUTEUR = aUTEUR;
	}

	/**
	 * @return the tHEME
	 */
	public String getTHEME() {
		return THEME;
	}

	/**
	 * @param tHEME the tHEME to set
	 */
	public void setTHEME(String tHEME) {
		THEME = tHEME;
	}

	/**
	 * @return the iSBN
	 */
	public int getISBN() {
		return ISBN;
	}

	/**
	 * @param iSBN the iSBN to set
	 */
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}

	/**
	 * @return the eTAT
	 */
	public String getETAT() {
		return ETAT;
	}

	/**
	 * @param eTAT the eTAT to set
	 */
	public void setETAT(String eTAT) {
		ETAT = eTAT;
	}

	/**
	 * @return the cOMMENTAIRE
	 */
	public String getCOMMENTAIRE() {
		return COMMENTAIRE;
	}

	/**
	 * @param cOMMENTAIRE the cOMMENTAIRE to set
	 */
	public void setCOMMENTAIRE(String cOMMENTAIRE) {
		COMMENTAIRE = cOMMENTAIRE;
	}

	/**
	 * @return the sTATUT
	 */
	public int getSTATUT() {
		return STATUT;
	}

	/**
	 * @param sTATUT the sTATUT to set
	 */
	public void setSTATUT(int sTATUT) {
		STATUT = sTATUT;
	}


static int ID_LIVRE;
String TITRE;
String AUTEUR;
String THEME;
int ISBN;
String ETAT;
String COMMENTAIRE;
int STATUT;


//Constructeur!!!
public livre(int iD_LIVRE, String tITRE, String aUTEUR, String tHEME,
		int iSBN, String eTAT, String cOMMENTAIRE, int sTATUT) {
	super();
	ID_LIVRE = iD_LIVRE;
	TITRE = tITRE;
	AUTEUR = aUTEUR;
	THEME = tHEME;
	ISBN = iSBN;
	ETAT = eTAT;
	COMMENTAIRE = cOMMENTAIRE;
	STATUT = sTATUT;
}

//ToString
@Override
public String toString() {
	return "livre [ ID_LIVRE = " + ID_LIVRE + ", TITRE = " + TITRE + ", AUTEUR = "
			+ AUTEUR + ", THEME = " + THEME + ", ISBN = " + ISBN + ", ETAT = "
			+ ETAT + ", COMMENTAIRE = " + COMMENTAIRE + ", STATUT = " + STATUT
			+ " ]";
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	livre l1 = new livre (1020,"ZUMA","Miya","SF",225588,"dispo","RAS",0)	;
		
	System.out.println(l1);	
		

	}

}
