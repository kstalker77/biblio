
public class employe extends personne{
public static int retard = 0;

/**
	 * @return the emprunt
	 */
	public emprunts getEmprunt() {
		return emprunt;
	}

	/**
	 * @param emprunt the emprunt to set
	 */
	public void setEmprunt(emprunts emprunt) {
		this.emprunt = emprunt;
	}

@Override
	public String toString() {
		if (fonction == null) {
			return "Employe : [ "+ " nom = " + nom
					+ ", prenom = " + prenom + ", no_telphone = " + no_telphone + 
		
					" no_matricule = " + no_matricule + ", no_carte =  "
					+ no_matricule + ", fonction = Indeterminée ";	
		}
		else {
	return "Employe : [ "+ " nom = " + nom
				+ ", prenom = " + prenom + ", no_telphone = " + no_telphone + 
	
				" no_matricule = " + no_matricule + ", no_carte =  "
				+ no_matricule + ", fonction = " + fonction + "]";}
	}

/**
	 * @param nom
	 * @param prenom
	 * @param no_telphone
	 * @param no_carte
	 */
	public employe(String nom, String prenom,
			int no_carte) {
		super(nom, prenom);
		this.no_carte = no_carte;
	}

/**
	 * @param nom
	 * @param prenom
	 * @param no_telphone
	 * @param no_matricule
	 */
	public employe(String nom, String prenom, String no_telphone,
			int no_matricule) {
		super(nom, prenom, no_telphone);
		this.no_matricule = no_matricule;
	}

int no_matricule;
int no_carte;
String fonction;
emprunts emprunt;
public static int nbemprunt;

/**
 * @param nom
 * @param prenom
 * @param no_telphone
 * @param no_matricule
 * @param no_carte
 * @param fonction
 */
public employe(String nom, String prenom, String no_telphone,
		int no_matricule, int no_carte, String fonction) {
	super(nom, prenom, no_telphone);
	this.no_matricule = no_matricule;
	if (no_carte == 0 || no_matricule !=0 ) {
	this.no_carte = no_matricule;}
	else no_carte = 0;
	this.fonction = fonction;
}

/**
 * @return the no_matricule
 */
public int getNo_matricule() {
	return no_matricule;
}

/**
 * @param no_matricule the no_matricule to set
 */
public void setNo_matricule(int no_matricule) {
	this.no_matricule = no_matricule;
}

/**
 * @return the no_carte
 */
public int getNo_carte() {
	return no_carte;
}

/**
 * @param no_carte the no_carte to set
 */
public void setNo_carte(int no_carte) {
	this.no_carte = no_carte;
}

/**
 * @return the fonction
 */
public String getFonction() {
	return fonction;
}

/**
 * @param fonction the fonction to set
 */
public void setFonction(String fonction) {
	this.fonction = fonction;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
employe em = new employe("LORRE","PETER","22558877",202,202, "ME");

System.out.println(em);
	};

}
